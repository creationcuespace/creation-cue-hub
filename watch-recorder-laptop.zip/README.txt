﻿========================================================
Creation Cue Watch Screen Recorder - Laptop Setup
========================================================

How to use:
1. Make sure Python is installed on your laptop (from https://www.python.org).
   * IMPORTANT: During Python installation, check the box "Add Python to PATH"!
2. Double-click "Start Watch Bridge.bat".
3. The browser will open http://127.0.0.1:37380 automatically.
4. Keep the black terminal window open while you record.
5. All recordings will be saved directly into your laptop's Downloads folder!
