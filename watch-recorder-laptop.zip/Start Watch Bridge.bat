@echo off
title Creation Cue Watch ADB Bridge
echo ========================================================
echo   Creation Cue Watch Screen Recorder - Laptop Bridge
echo ========================================================
echo.
echo Starting bridge on http://localhost:37380...
start "" "https://creationcue.web.app/watch-recorder"
python "%~dp0watch_bridge.py"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ========================================================
    echo [ERROR] Python was not found on your system!
    echo Please install Python from https://www.python.org/
    echo Make sure to check "Add Python to PATH" during setup.
    echo ========================================================
    echo.
    pause
)
